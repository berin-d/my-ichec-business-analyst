from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.secret_key = 'cle_secrete_examen_budgetflow'

basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'budgetflow.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# --- MODÈLES ---

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='employe')  # 'employe' ou 'manager'

# TODO (I) : Définir le modèle BudgetRequest
# Colonnes : title, amount, justification, status (défaut 'en_attente'),
#            decision_comment, author_id (clé étrangère vers User)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- ROUTES ---

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username).first()
        if user:
            flash('Ce nom d\'utilisateur est déjà pris.', 'danger')
            return redirect(url_for('register'))

        new_user = User(username=username, password_hash=generate_password_hash(password, method='scrypt'))
        db.session.add(new_user)
        db.session.commit()

        login_user(new_user)
        return redirect(url_for('index'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username).first()

        if not user or not check_password_hash(user.password_hash, password):
            flash('Identifiants incorrects.', 'danger')
            return redirect(url_for('login'))

        login_user(user)
        return redirect(url_for('index'))
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

# TODO (I) : Implémenter la route GET/POST /budget/new
# - Valider que le montant est strictement positif
# - Créer et persister un BudgetRequest lié à current_user

# TODO (I) : Implémenter la route GET /budget/list
# - Manager : voir toutes les demandes
# - Employé : voir uniquement ses propres demandes

# TODO (II) : Implémenter la route POST /budget/<id>/decide
# - Réservée aux managers (erreur 403 sinon)
# - Accepte une décision ('approuve' ou 'rejete') et un commentaire obligatoire

# --- PARTIE III : STATISTIQUES (code existant à auditer et corriger) ---

@app.route('/budget/stats')
@login_required
def budget_stats():
    # BUG 1 : Tous les utilisateurs voient les statistiques globales de l'entreprise
    requests = BudgetRequest.query.all()

    total_approved = 0
    total_pending = 0
    for r in requests:
        if r.status == 'approuve':
            total_approved += r.amount
        if r.status == 'en_attente':
            total_pending += r.amount

    # BUG 2 : Le total ignore les demandes rejetées
    return render_template('stats.html',
        total_approved=total_approved,
        total_pending=total_pending,
        total=total_approved + total_pending,
        count=len(requests)
    )

# --- INITIALISATION ---

def init_db():
    with app.app_context():
        db.create_all()
        if not User.query.first():
            admin = User(username='manager1', password_hash=generate_password_hash('manager1', method='scrypt'), role='manager')
            employe = User(username='employe1', password_hash=generate_password_hash('employe1', method='scrypt'), role='employe')
            db.session.add_all([admin, employe])
            db.session.commit()

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0')
