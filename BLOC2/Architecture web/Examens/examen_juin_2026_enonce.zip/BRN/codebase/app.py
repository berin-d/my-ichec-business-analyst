from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.secret_key = 'cle_secrete_examen_leavemanager'

basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'leavemanager.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# --- MODÈLES ---

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='employe')  # 'employe' ou 'manager'
    total_leave_days = db.Column(db.Integer, default=25)

    # TODO (I) : ajouter la relation vers les demandes de congé.


# TODO (I) : définir le modèle LeaveRequest
# Il doit permettre de stocker les informations décrites dans l'énoncé.


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# --- ROUTES D'AUTHENTIFICATION ---

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username).first()
        if user:
            flash('Ce nom d\'utilisateur est déjà pris.', 'danger')
            return redirect(url_for('register'))

        new_user = User(username=username, password_hash=generate_password_hash(password, method='scrypt'))
        db.session.add(new_user)
        db.session.commit()

        login_user(new_user)
        return redirect(url_for('index'))
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username).first()
        if not user or not check_password_hash(user.password_hash, password):
            flash('Identifiants incorrects.', 'danger')
            return redirect(url_for('login'))

        login_user(user)
        return redirect(url_for('index'))
    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))


# TODO (I) : implémenter la route GET/POST /leave/new
# - Créer une demande liée à l'utilisateur connecté
# - Valider un nombre de jours strictement positif
# - Refuser une demande de congé annuel si le solde disponible est insuffisant


# TODO (I) : implémenter la route GET /leave/list
# - Manager : voir toutes les demandes
# - Employé : voir uniquement ses propres demandes


# TODO (II) : implémenter la route POST /leave/<id>/decide
# - Réservée aux managers (erreur 403 sinon)
# - Accepte une décision et un commentaire obligatoire
# - Un manager ne peut pas décider sur sa propre demande


# --- INITIALISATION ---

def init_db():
    with app.app_context():
        db.create_all()
        if not User.query.first():
            manager = User(
                username='manager1',
                password_hash=generate_password_hash('manager1', method='scrypt'),
                role='manager',
                total_leave_days=30
            )
            employe1 = User(
                username='employe1',
                password_hash=generate_password_hash('employe1', method='scrypt'),
                role='employe',
                total_leave_days=25
            )
            employe2 = User(
                username='employe2',
                password_hash=generate_password_hash('employe2', method='scrypt'),
                role='employe',
                total_leave_days=25
            )
            db.session.add_all([manager, employe1, employe2])
            db.session.commit()


if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0')
