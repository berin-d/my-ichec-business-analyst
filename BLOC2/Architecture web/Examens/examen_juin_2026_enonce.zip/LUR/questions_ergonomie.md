# Examen d'architecture Web: questions de la partie ergonomie

1. Pour un site web, qu'entend-on par « accessibilité » ? À quels éléments
   doit-on faire attention pour avoir un haut niveau d’accessibilité ?

   Votre réponse:

2. Pour un site web, qu'entend-on par « Responsive Design » ?

   Votre réponse:
