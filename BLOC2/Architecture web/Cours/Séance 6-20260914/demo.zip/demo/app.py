from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import or_, desc

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///features.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'super-secret-key'

db = SQLAlchemy(app)

# --- Modèles ---

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    features = db.relationship('Feature', backref='author', lazy=True)

class Feature(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    priority = db.Column(db.String(20), default='Moyenne')
    is_done = db.Column(db.Boolean, default=False)  # Nouveau: db.Boolean
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

# --- Initialisation de la base ---
with app.app_context():
    db.create_all()
    if not User.query.filter_by(username='admin').first():
        admin = User(username='admin')
        db.session.add(admin)
        db.session.commit()

# --- Routes ---

@app.route('/')
def index():
    query = Feature.query
    
    # 1. Filtre Avancé: Recherche (LIKE)
    search = request.args.get('q')
    if search:
        query = query.filter(Feature.title.contains(search))
    
    # 2. Tri Avancé (order_by)
    sort = request.args.get('sort', 'id')
    if sort == 'title':
        query = query.order_by(Feature.title)
    elif sort == 'priority':
        query = query.order_by(Feature.priority)
    else:
        query = query.order_by(desc(Feature.id))
        
    features = query.all()
    return render_template('index.html', features=features, search=search)

@app.route('/add', methods=['GET', 'POST'])
def add_feature():
    if request.method == 'POST':
        try:
            admin = User.query.filter_by(username='admin').first()
            new_feature = Feature(
                title=request.form.get('title'), 
                description=request.form.get('description'), 
                priority=request.form.get('priority'),
                author=admin
            )
            db.session.add(new_feature)
            db.session.commit()
            flash('Fonctionnalité ajoutée !')
            return redirect(url_for('index'))
        except Exception as e:
            db.session.rollback()  # Démo du rollback
            flash(f"Erreur lors de l'ajout : {str(e)}", "danger")
            
    return render_template('add.html')

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_feature(id):
    feature = Feature.query.get_or_404(id) # demo get_or_404
    
    if request.method == 'POST':
        try:
            # Update (Modification)
            feature.title = request.form.get('title')
            feature.description = request.form.get('description')
            feature.priority = request.form.get('priority')
            feature.is_done = 'is_done' in request.form
            
            db.session.commit() # SQLAlchemy détecte les changements
            flash('Modifications enregistrées !')
            return redirect(url_for('index'))
        except Exception as e:
            db.session.rollback()
            flash("Erreur lors de la modification.", "danger")
            
    return render_template('edit.html', feature=feature)

@app.route('/delete/<int:id>')
def delete_feature(id):
    feature = Feature.query.get_or_404(id)
    db.session.delete(feature)
    db.session.commit()
    flash('Fonctionnalité supprimée.')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
