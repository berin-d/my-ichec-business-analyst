from flask import Flask, request, render_template, redirect, url_for, abort

app = Flask(__name__)

# --- 1. ROUTING BASICS ---

# Multiple routes for one function
@app.route('/')
@app.route('/home')
def index():
    return render_template('index.html')

# --- 2. DYNAMIC ROUTING & CONVERTERS ---

@app.route('/user/<username>')
def show_user_profile(username):
    # username is a string by default
    return f"User profile: {username}"

@app.route('/order/<int:order_id>')
def show_order(order_id):
    # order_id is converted to an integer
    return f"Order ID: {order_id} (Type: {type(order_id).__name__})"

@app.route('/calculate/<float:value>')
def calculate(value):
    # value is converted to a float
    result = value * 1.21
    return f"Value with 21% VAT: {result:.2f}"

# --- 3. REQUEST OBJECT ---

@app.route('/search')
def search():
    # Demonstrating Query Parameters: /search?q=flask&page=1
    query = request.args.get('q', '')
    page = request.args.get('page', 1)
    return f"Searching for '{query}' on page {page}"

@app.route('/login', methods=['GET', 'POST'])
def login():
    # Demonstrating Request Methods and Form Data
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # In a real app, we would verify credentials here
        if username == "admin" and password == "secret":
            return f"Welcome back, {username}! (Method: {request.method})"
        else:
            return "Invalid credentials.", 401
            
    return render_template('login.html')

# --- 4. REDIRECTS & ABORTS ---

@app.route('/old-login')
def old_login():
    # Redirecting to the new login page
    return redirect(url_for('login'))

@app.route('/secret')
def secret():
    # Demonstration of abort()
    role = request.args.get('role')
    if role != 'admin':
        abort(403) # Forbidden
    return "This is a secret restricted zone."

# --- 5. ERROR HANDLING ---

@app.errorhandler(404)
def page_not_found(e):
    # Custom error handler for 404
    return "<h1>404 - Oups ! Cette page n'existe pas.</h1><p>Retournez à l'accueil.</p>", 404

@app.errorhandler(403)
def forbidden(e):
    return "<h1>403 - Accès interdit !</h1><p>Vous n'avez pas les droits nécessaires.</p>", 403

if __name__ == '__main__':
    # Running with debug=True allows live reloading
    app.run(host='0.0.0.0', port=5000, debug=True)
