from flask import Flask, render_template, request, session, g

app = Flask(__name__)
app.secret_key = 'super_secret_for_demo'

# Mock data
FEATURES = [
    {"id": 1, "title": "Mode Sombre", "desc": "Interface sombre pour le confort visuel des utilisateurs nocturnes.", "active": True},
    {"id": 2, "title": "Export PDF", "desc": "Générer un rapport PDF en un clic.", "active": False},
    {"id": 3, "title": "IA Priorisation", "desc": "Utiliser l'IA pour classer les demandes critiques.", "active": True},
]

@app.before_request
def before_request():
    g.user_role = "Business Analyst"

@app.route('/')
def index():
    # Simulation d'une session
    session['username'] = "Nicolas"
    
    # Données brutes pour le test de sécurité (XSS)
    raw_html = "<strong>Attention:</strong> Donnée HTML brute."
    
    return render_template(
        'index.html', 
        features=FEATURES, 
        raw_html=raw_html,
        app_name="WebArch Demo"
    )

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
