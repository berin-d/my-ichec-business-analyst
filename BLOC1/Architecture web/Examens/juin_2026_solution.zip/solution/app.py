from flask import Flask, render_template, request, redirect, url_for, flash, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.secret_key = 'cle_secrete_examen_leavemanager'

basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'leavemanager.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='employe')
    total_leave_days = db.Column(db.Integer, default=25)

    leave_requests = db.relationship('LeaveRequest', backref='employee', lazy=True)

    def get_available_leave_days(self):
        reserved_days = 0
        for leave in self.leave_requests:
            if leave.leave_type == 'conge_annuel' and leave.status in ['approuve', 'en_attente']:
                reserved_days += leave.days_requested
        return self.total_leave_days - reserved_days


class LeaveRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    start_date = db.Column(db.String(10), nullable=False)
    end_date = db.Column(db.String(10), nullable=False)
    days_requested = db.Column(db.Integer, nullable=False)
    leave_type = db.Column(db.String(30), nullable=False)
    reason = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(20), default='en_attente')
    manager_comment = db.Column(db.Text, nullable=True)
    employee_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'start_date': self.start_date,
            'end_date': self.end_date,
            'days_requested': self.days_requested,
            'leave_type': self.leave_type,
            'reason': self.reason,
            'status': self.status,
            'manager_comment': self.manager_comment,
            'employee_id': self.employee_id,
            'employee_username': self.employee.username
        }


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username).first()
        if user:
            flash('Ce nom d\'utilisateur est deja pris.', 'danger')
            return redirect(url_for('register'))

        new_user = User(username=username, password_hash=generate_password_hash(password, method='scrypt'))
        db.session.add(new_user)
        db.session.commit()

        login_user(new_user)
        return redirect(url_for('index'))
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username).first()
        if not user or not check_password_hash(user.password_hash, password):
            flash('Identifiants incorrects.', 'danger')
            return redirect(url_for('login'))

        login_user(user)
        return redirect(url_for('index'))
    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))


@app.route('/leave/new', methods=['GET', 'POST'])
@login_required
def leave_new():
    if request.method == 'POST':
        start_date = request.form.get('start_date')
        end_date = request.form.get('end_date')
        leave_type = request.form.get('leave_type')
        reason = request.form.get('reason')

        try:
            days_requested = int(request.form.get('days_requested') or 0)
        except ValueError:
            days_requested = 0

        if days_requested <= 0:
            flash('Le nombre de jours doit etre strictement positif.', 'danger')
            return redirect(url_for('leave_new'))

        if leave_type == 'conge_annuel' and days_requested > current_user.get_available_leave_days():
            flash('Solde de conge annuel insuffisant.', 'danger')
            return redirect(url_for('leave_new'))

        leave = LeaveRequest(
            start_date=start_date,
            end_date=end_date,
            days_requested=days_requested,
            leave_type=leave_type,
            reason=reason,
            employee_id=current_user.id
        )
        db.session.add(leave)
        db.session.commit()

        flash('Demande de conge soumise avec succes.', 'success')
        return redirect(url_for('leave_list'))

    return render_template('leave_new.html')


@app.route('/leave/list')
@login_required
def leave_list():
    if current_user.role == 'manager':
        leaves = LeaveRequest.query.all()
    else:
        leaves = LeaveRequest.query.filter_by(employee_id=current_user.id).all()
    return render_template('leave_list.html', leaves=leaves)


@app.route('/leave/<int:id>/decide', methods=['POST'])
@login_required
def leave_decide(id):
    if current_user.role != 'manager':
        abort(403)

    leave = LeaveRequest.query.get_or_404(id)
    if leave.employee_id == current_user.id:
        abort(403)

    decision = request.form.get('decision')
    comment = request.form.get('manager_comment', '').strip()

    if decision not in ['approuve', 'rejete']:
        flash('Decision invalide.', 'danger')
        return redirect(url_for('leave_list'))

    if not comment:
        flash('Un commentaire manager est obligatoire.', 'danger')
        return redirect(url_for('leave_list'))

    if decision == 'approuve' and leave.leave_type == 'conge_annuel':
        available_days = leave.employee.get_available_leave_days()
        if leave.status == 'en_attente':
            available_days += leave.days_requested
        if leave.days_requested > available_days:
            flash('Solde insuffisant pour approuver cette demande.', 'danger')
            return redirect(url_for('leave_list'))

    leave.status = decision
    leave.manager_comment = comment
    db.session.commit()

    flash('Decision enregistree.', 'success')
    return redirect(url_for('leave_list'))


def init_db():
    with app.app_context():
        db.create_all()
        if not User.query.first():
            manager = User(
                username='manager1',
                password_hash=generate_password_hash('manager1', method='scrypt'),
                role='manager',
                total_leave_days=30
            )
            employe1 = User(
                username='employe1',
                password_hash=generate_password_hash('employe1', method='scrypt'),
                role='employe',
                total_leave_days=25
            )
            employe2 = User(
                username='employe2',
                password_hash=generate_password_hash('employe2', method='scrypt'),
                role='employe',
                total_leave_days=25
            )
            db.session.add_all([manager, employe1, employe2])
            db.session.commit()


if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0')
