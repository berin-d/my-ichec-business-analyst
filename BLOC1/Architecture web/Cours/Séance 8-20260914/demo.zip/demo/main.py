from flask import Flask, session, redirect, url_for

app = Flask(__name__)
app.secret_key = 'une_cle_tres_secrete' # Crucial pour la signature

@app.route('/login')
def login():
    session['user_id'] = 123
    return "Connecté !"

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return "Déconnecté !"

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
