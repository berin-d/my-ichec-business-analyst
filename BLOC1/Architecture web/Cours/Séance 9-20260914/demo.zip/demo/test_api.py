import requests
import json
import time

BASE_URL = "http://api:5000/api/features"

def print_response(response, title):
    print(f"\n=== {title} ===")
    print(f"Request URL: {response.url}")
    print(f"Status Code: {response.status_code}")
    try:
        if response.status_code != 204:
            print(json.dumps(response.json(), indent=2, ensure_ascii=False))
    except Exception:
        print(f"Content (first 100 chars): {response.text[:100]}")

def test_api():
    # Attente que l'API soit prête
    max_retries = 5
    for i in range(max_retries):
        try:
            requests.get(BASE_URL)
            break
        except requests.exceptions.ConnectionError:
            print(f"En attente de l'API ({i+1}/{max_retries})...")
            time.sleep(2)
    else:
        print("Erreur: Impossible de se connecter à l'API après plusieurs tentatives.")
        return

    # 1. Créer une nouvelle ressource (POST)
    payload = {
        "title": "Ajouter un export CSV",
        "description": "Permettre aux utilisateurs d'exporter leurs données en CSV",
        "priority": 3
    }
    response = requests.post(BASE_URL, json=payload)
    print_response(response, "POST: Création d'une fonctionnalité")
    
    if response.status_code == 201:
        feature_id = response.json().get('id')
    else:
        print("Erreur lors de la création, arrêt des tests.")
        return

    # 2. Lister toutes les ressources (GET)
    response = requests.get(BASE_URL)
    print_response(response, "GET: Liste de toutes les fonctionnalités")

    # 3. Récupérer les détails d'une ressource (GET)
    response = requests.get(f"{BASE_URL}/{feature_id}")
    print_response(response, f"GET: Détails de la fonctionnalité {feature_id}")

    # 4. Tester le filtrage - priorité 3 (devrait inclure la feature créée)
    response = requests.get(f"{BASE_URL}?priority=3")
    print_response(response, "GET: Filtrage par priorité=3")

    # 5. Tester le filtrage - priorité 99 (devrait être vide)
    response = requests.get(f"{BASE_URL}?priority=99")
    print_response(response, "GET: Filtrage par priorité=99 (devrait être vide)")

    # 6. Mettre à jour la ressource (PUT)
    update_payload = {
        "title": "Ajouter un export CSV EXCEL",
        "priority": 5,
        "status": "in-progress"
    }
    response = requests.put(f"{BASE_URL}/{feature_id}", json=update_payload)
    print_response(response, f"PUT: Mise à jour de la fonctionnalité {feature_id}")

    # 5. Authentification JWT pour le DELETE
    login_payload = {"username": "admin", "password": "secret"}
    response = requests.post(f"{BASE_URL.replace('/features', '')}/login", json=login_payload)
    print_response(response, "POST /api/login : Obtention du token JWT")
    token = response.json().get("access_token")

    # 5b. Tester le DELETE sans token (doit retourner 401)
    response = requests.delete(f"{BASE_URL}/{feature_id}")
    print_response(response, f"DELETE sans token (doit être 401)")

    # 5c. Supprimer la ressource avec le token Bearer
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.delete(f"{BASE_URL}/{feature_id}", headers=headers)
    print_response(response, f"DELETE avec token: Suppression de la fonctionnalité {feature_id}")

    # 6. Vérifier la suppression
    response = requests.get(f"{BASE_URL}/{feature_id}")
    print_response(response, f"GET: Vérification après suppression (devrait être 404)")

if __name__ == "__main__":
    try:
        test_api()
    except requests.exceptions.ConnectionError:
        print("Erreur: Impossible de se connecter à l'API. Assurez-vous que le conteneur Docker est lancé sur le port 5000.")
