from flask import Blueprint, jsonify, request, abort
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from .models import db, FeatureRequest

api = Blueprint('api', __name__)

# --- Gestion standardisée des erreurs (RFC 7807 simplifié) ---
def make_error(status_code, message, field=None):
    response = {"error": message, "code": status_code}
    if field:
        response["field"] = field
    return jsonify(response), status_code

@api.errorhandler(404)
def not_found(error):
    return make_error(404, "Ressource introuvable")

@api.errorhandler(400)
def bad_request(error):
    return make_error(400, "Requête invalide")

# --- Routes API ---

# POST /api/login - Authentification et génération de JWT
@api.route('/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    username = data.get('username')
    password = data.get('password')
    
    # Authentification factice pour la démo
    if username == 'admin' and password == 'secret':
        access_token = create_access_token(identity=username)
        return jsonify(access_token=access_token), 200
    
    return make_error(401, "Identifiants invalides")

# GET /api/features - Liste avec Filtrage, Tri et Pagination
@api.route('/features', methods=['GET'])
def get_features():
    # Paramètres de filtrage
    priority = request.args.get('priority', type=int)
    status = request.args.get('status', type=str)
    
    # Paramètres de tri
    sort = request.args.get('sort', type=str)
    order = request.args.get('order', default='asc', type=str)
    
    # Paramètres de pagination
    page = request.args.get('page', default=1, type=int)
    per_page = request.args.get('per_page', default=10, type=int)

    query = FeatureRequest.query
    
    # 1. Filtrage
    if priority is not None:
        query = query.filter_by(priority=priority)
    if status is not None:
        query = query.filter_by(status=status)
        
    # 2. Tri
    if sort:
        column = getattr(FeatureRequest, sort, None)
        if column:
            if order == 'desc':
                query = query.order_by(column.desc())
            else:
                query = query.order_by(column.asc())

    # 3. Pagination
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        "total": pagination.total,
        "page": pagination.page,
        "pages": pagination.pages,
        "per_page": pagination.per_page,
        "data": [f.to_dict() for f in pagination.items]
    })

# GET /api/features/<id> - Détails d'une demande
@api.route('/features/<int:id>', methods=['GET'])
def get_feature(id):
    feature = FeatureRequest.query.get_or_404(id)
    return jsonify(feature.to_dict())

# POST /api/features - Créer une demande
@api.route('/features', methods=['POST'])
def create_feature():
    data = request.get_json() or {}
    if 'title' not in data:
        return make_error(400, "Le titre est requis", "title")
    
    feature = FeatureRequest(
        title=data.get('title'),
        description=data.get('description'),
        priority=data.get('priority', 1)
    )
    db.session.add(feature)
    db.session.commit()
    
    return jsonify(feature.to_dict()), 201

# PUT /api/features/<id> - Remplacement complet
@api.route('/features/<int:id>', methods=['PUT'])
def update_feature_put(id):
    feature = FeatureRequest.query.get_or_404(id)
    data = request.get_json() or {}
    
    if 'title' not in data:
        return make_error(400, "Le titre est requis pour un remplacement complet", "title")
        
    # Le PUT écrase tout. Ce qui n'est pas fourni est mis à null ou à la valeur par défaut.
    feature.title = data['title']
    feature.description = data.get('description')
    feature.priority = data.get('priority', 1)
    feature.status = data.get('status', 'pending')
    
    db.session.commit()
    return jsonify(feature.to_dict())

# PATCH /api/features/<id> - Modification partielle
@api.route('/features/<int:id>', methods=['PATCH'])
def update_feature_patch(id):
    feature = FeatureRequest.query.get_or_404(id)
    data = request.get_json() or {}
    
    # Le PATCH ne modifie que ce qui est fourni
    if 'title' in data:
        feature.title = data['title']
    if 'description' in data:
        feature.description = data['description']
    if 'priority' in data:
        feature.priority = data['priority']
    if 'status' in data:
        feature.status = data['status']
        
    db.session.commit()
    return jsonify(feature.to_dict())

# DELETE /api/features/<id> - Supprimer une demande (Protégé par JWT)
@api.route('/features/<int:id>', methods=['DELETE'])
@jwt_required()
def delete_feature(id):
    feature = FeatureRequest.query.get_or_404(id)
    db.session.delete(feature)
    db.session.commit()
    return '', 204
