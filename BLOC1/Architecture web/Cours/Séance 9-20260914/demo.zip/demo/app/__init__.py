from flask import Flask
from .models import db

import os

def create_app():
    app = Flask(__name__)
    # Utilisation d'un chemin absolu pour la DB dans le dossier instance
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(app.instance_path, 'api.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)

    from flask_jwt_extended import JWTManager
    app.config["JWT_SECRET_KEY"] = "super-secret-key-pour-la-demo"
    jwt = JWTManager(app)

    from .routes import api
    app.register_blueprint(api, url_prefix='/api')

    with app.app_context():
        db.create_all()

    return app
