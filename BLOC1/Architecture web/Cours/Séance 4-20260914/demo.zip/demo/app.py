import os
from werkzeug.utils import secure_filename
from flask import Flask, request, render_template, flash, redirect, url_for

app = Flask(__name__)
app.secret_key = 'session4_demo_key'
app.config['UPLOAD_FOLDER'] = 'static/uploads'

# S'assurer que le dossier d'upload existe
os.makedirs(os.path.join(app.root_path, app.config['UPLOAD_FOLDER']), exist_ok=True)

# Simulation de base de données (liste en mémoire)
FEATURES = [
    {"title": "Mode Sombre", "desc": "Assombrir l'interface", "priority": "Moyenne", "tags": ["UI"], "filename": None},
    {"title": "Export CSV", "desc": "Télécharger les données", "priority": "Basse", "tags": ["Data"], "filename": None},
]

@app.route('/')
def index():
    # 6. Gestion des paramètres GET (Recherche)
    search_query = request.args.get('q', '').lower()
    filtered_features = FEATURES
    
    if search_query:
        filtered_features = [
            f for f in FEATURES 
            if search_query in f['title'].lower() or search_query in f['desc'].lower()
        ]
        
    return render_template('index.html', features=filtered_features, search_query=search_query)

@app.route('/add', methods=['GET', 'POST'])
def add_feature():
    if request.method == 'POST':
        # 1. Récupération des données du formulaire
        title = request.form.get('title')
        description = request.form.get('desc')
        priority = request.form.get('priority')
        tags = request.form.getlist('tags') # Liste de checkboxes

        # 2. Gestion du fichier
        file = request.files.get('screenshot')
        filename = None
        if file and file.filename != '':
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.root_path, app.config['UPLOAD_FOLDER'], filename))

        # 3. Validation simple
        if not title or not description:
            flash("Erreur : Tous les champs sont obligatoires.", "danger")
            return redirect(url_for('add_feature'))

        # 4. Traitement
        new_feature = {
            "title": title,
            "desc": description,
            "priority": priority,
            "tags": tags,
            "filename": filename
        }
        FEATURES.insert(0, new_feature)

        # 5. Message de succès et Redirection (Pattern PRG)
        flash(f"La fonctionnalité '{title}' a été ajoutée !", "success")
        return redirect(url_for('index'))

    # Si GET, on affiche simplement le formulaire
    return render_template('add_feature.html')

if __name__ == '__main__':
    app.run(debug=True, port=5000)
