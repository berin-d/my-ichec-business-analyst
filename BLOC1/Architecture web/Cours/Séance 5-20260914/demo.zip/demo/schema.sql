-- 1. Suppression des anciennes tables (pour repartir de zéro)
DROP TABLE IF EXISTS features;
DROP TABLE IF EXISTS users;

-- 2. Création de la table des utilisateurs
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    email TEXT NOT NULL
);

-- 3. Création de la table des fonctionnalités
CREATE TABLE features (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    priority TEXT DEFAULT 'Moyenne',
    status TEXT DEFAULT 'A faire',
    author_id INTEGER,
    FOREIGN KEY(author_id) REFERENCES users(id)
);

-- 4. Insertion de données de test
INSERT INTO users (username, email) VALUES 
('Nicolas', 'nicolas@test.be'),
('Julie', 'julie@test.be'),
('Audit_Bot', 'audit@test.be');

INSERT INTO features (title, description, priority, author_id) VALUES 
('Authentification', 'Permettre aux users de se connecter', 'Haute', 1),
('Export PDF', 'Générer un rapport des demandes', 'Basse', 1),
('API Priority', 'Calcul automatique de la priorité', 'Moyenne', 2),
('Patch Sécurité', 'Corriger la faille XSS signalée', 'Haute', 3);
