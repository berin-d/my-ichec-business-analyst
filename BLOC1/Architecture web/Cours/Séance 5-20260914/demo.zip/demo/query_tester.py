import sqlite3
import os

# Configuration des fichiers de la base de données
DB_FILE = 'featurehub.db'
SCHEMA_FILE = 'schema.sql'

def init_db():
    """
    Supprime la base de données existante et la recrée à partir du fichier de schéma.
    Utile pour réinitialiser les données avant d'exécuter des tests.
    """
    if os.path.exists(DB_FILE):
        os.remove(DB_FILE)
    
    # Connexion et exécution du script SQL contenant les CREATE TABLE et INSERT
    conn = sqlite3.connect(DB_FILE)
    with open(SCHEMA_FILE, 'r') as f:
        schema = f.read()
        conn.executescript(schema)
    conn.commit()
    conn.close()
    print(f"Base de données {DB_FILE} créée et initialisée.")

def run_query(query):
    """
    Exécute une requête SQL et affiche le résultat formaté dans la console.
    """
    conn = sqlite3.connect(DB_FILE)
    # Permet d'accéder aux colonnes par leur nom via la clé du dictionnaire
    conn.row_factory = sqlite3.Row
    try:
        cursor = conn.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        
        if rows:
            # Extraction des noms de colonnes pour l'en-tête
            headers = rows[0].keys()
            print(" | ".join(headers))
            print("-" * 40)
            # Affichage de chaque ligne de résultat
            for row in rows:
                print(" | ".join(str(val) for val in row))
        else:
            print("Aucun résultat.")
    except Exception as e:
        print(f"Erreur SQL : {e}")
    finally:
        # Toujours fermer la connexion pour libérer les ressources
        conn.close()

if __name__ == "__main__":
    # Initialisation de la base (création des tables et données de test)
    init_db()
    
    # Test d'une requête de sélection basique
    print("\n--- Test SELECT simple ---")
    run_query("SELECT id, title, priority FROM features;")
    
    # Test d'une jointure (JOIN) pour récupérer le nom de l'auteur d'une feature
    print("\n--- Test JOIN (Features & Users) ---")
    run_query("""
        SELECT f.title, u.username 
        FROM features f 
        JOIN users u ON f.author_id = u.id;
    """)
