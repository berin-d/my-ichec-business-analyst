from flask import Blueprint, render_template
from app.models import Feature

main = Blueprint('main', __name__)

@main.route('/')
def index():
    features = Feature.query.all()
    return render_template('main/index.html', features=features)
