class Config:
    SECRET_KEY = 'super-secret-key-modular'
    SQLALCHEMY_TRACK_MODIFICATIONS = False


class DevConfig(Config):
    SQLALCHEMY_DATABASE_URI = 'sqlite:///features.db'


class ProdConfig(Config):
    SQLALCHEMY_DATABASE_URI = 'postgresql://user:password@remote-db/prod'
