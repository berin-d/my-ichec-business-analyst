from flask import Flask
from app.models import db, User
from app.config import DevConfig

def create_app(config_class=DevConfig):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialisation des extensions
    db.init_app(app)
    
    # Enregistrement des Blueprints
    from app.main.routes import main
    from app.features.routes import features
    
    app.register_blueprint(main)
    app.register_blueprint(features, url_prefix='/features')
    
    # Initialisation de la base (pour la démo)
    with app.app_context():
        db.create_all()
        if not User.query.filter_by(username='admin').first():
            admin = User(username='admin')
            db.session.add(admin)
            db.session.commit()
            
    return app
