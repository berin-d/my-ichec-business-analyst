from flask import Blueprint, render_template, request, redirect, url_for, flash
from app.models import db, Feature, User

features = Blueprint('features', __name__)

@features.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        try:
            admin = User.query.filter_by(username='admin').first()
            new_f = Feature(
                title=request.form.get('title'),
                description=request.form.get('description'),
                priority=request.form.get('priority'),
                author=admin
            )
            db.session.add(new_f)
            db.session.commit()
            flash('Succès !')
            return redirect(url_for('main.index'))
        except:
            db.session.rollback()
            flash('Erreur !', 'danger')
    return render_template('features/add.html')

@features.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    f = Feature.query.get_or_404(id)
    if request.method == 'POST':
        f.title = request.form.get('title')
        f.description = request.form.get('description')
        f.priority = request.form.get('priority')
        f.is_done = 'is_done' in request.form
        db.session.commit()
        flash('Modifié !')
        return redirect(url_for('main.index'))
    return render_template('features/edit.html', feature=f)

@features.route('/delete/<int:id>')
def delete(id):
    f = Feature.query.get_or_404(id)
    db.session.delete(f)
    db.session.commit()
    return redirect(url_for('main.index'))
